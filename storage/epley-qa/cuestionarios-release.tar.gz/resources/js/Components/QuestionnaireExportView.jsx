import { QUESTIONNAIRE_THEMES as QT } from '@/Components/Questionnaires/presentation';
import BarreExport from '@/Pages/Questionnaires/Barre/Export';
import EpleyExport from '@/Pages/Questionnaires/Epley/Export';
import { formatDateShort } from '@/Utils/dateFormatter';

/**
 * `hiddenFields` es la lista de campos que ese equipo no debe ver, resuelta por
 * el servidor (App\Support\QuestionnaireFields). Viene como prop y no como prop
 * de Inertia porque el JPG se arma en un html2canvas aparte del render normal:
 * sin esto, un PDF exportado por un Rojo dejaría ver "Hiperativo?", que en la
 * pantalla nunca se le muestra.
 */
export default function QuestionnaireExportView({ questionnaire, type = 'electroencefalograma', hiddenFields = [] }) {
    const sees = (field) => !hiddenFields.includes(field);

    const InfoRow = ({ label, value }) => (
        <div className="mb-1">
            <span className="text-xs font-semibold text-gray-700">{label}</span>
            <div className="text-xs text-gray-900">{value}</div>
        </div>
    );

    const BooleanRow = ({ label, value, conditionalValue = null }) => (
        <div className="mb-1">
            <span className="text-xs font-semibold text-gray-700">{label}</span>
            <div className="text-xs text-gray-900">
                {value ? 'Sim' : 'Não'}
                {value && conditionalValue && (
                    <span className="ml-1 text-gray-700">({conditionalValue})</span>
                )}
            </div>
        </div>
    );

    if (type === 'barre') return <BarreExport questionnaire={questionnaire} />;

    if (type === 'epley') return <EpleyExport questionnaire={questionnaire} />;

    if (type === 'electroencefalograma') {
        return (
            <div className="bg-white" style={{ width: '210mm', height: '297mm', padding: '10mm', fontFamily: 'Arial, sans-serif', fontSize: '11px' }}>
                {/* Header */}
                <div className={QT.electroencefalograma.header + " px-3 py-2 mb-3"} style={{ borderRadius: '3px' }}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-sm font-bold mb-0" style={{ lineHeight: '1.2' }}>Sistema de Questionários - EEG</h1>
                            <p className="text-xs mb-0" style={{ lineHeight: '1.2' }}>Eletroencefalograma</p>
                        </div>
                        <div className="text-right" style={{ fontSize: '9px', lineHeight: '1.3' }}>
                            <div>Data de Exportação: {new Date().toLocaleDateString('pt-BR')} {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                            <div>Paciente: {questionnaire.nome_completo}</div>
                        </div>
                    </div>
                </div>

                {/* Informações do Paciente */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Informações do Paciente</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome Completo" value={questionnaire.nome_completo} />
                        <InfoRow label="Data do Exame" value={formatDateShort(questionnaire.data_exame)} />
                        <InfoRow label="RG ou CPF" value={questionnaire.rg_ou_cpf} />
                        <InfoRow label="Clínica" value={questionnaire.clinica} />
                        <InfoRow label="Data de Nascimento" value={formatDateShort(questionnaire.data_nascimento)} />
                        <InfoRow label="Equipe" value={questionnaire.team.name} />
                        <InfoRow label="Idade" value={questionnaire.idade} />
                        <InfoRow label="Tipo de Exame" value={questionnaire.tipo_exame || 'FOTO'} />
                        <InfoRow label="Sexo" value={questionnaire.sexo} />
                        <InfoRow label="Momento do Exame" value={questionnaire.momento_exame} />
                    </div>
                </div>

                {/* Histórico Médico */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Histórico Médico</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <BooleanRow label="Teve COVID-19?" value={questionnaire.teve_covid} />
                        <BooleanRow label="Teve desmaio?" value={questionnaire.teve_desmaio} />
                        <BooleanRow 
                            label="Já teve AVC?" 
                            value={questionnaire.ja_teve_avc}
                            conditionalValue={questionnaire.quando_teve_avc}
                        />
                        <BooleanRow 
                            label="Já teve convulsão?" 
                            value={questionnaire.ja_teve_convulsao}
                            conditionalValue={questionnaire.quando_teve_convulsao}
                        />
                        <BooleanRow label="Já bateu a cabeça?" value={questionnaire.ja_bateu_cabeca} />
                        <BooleanRow label="Tem dor de cabeça?" value={questionnaire.tem_dor_cabeca} />
                    </div>
                </div>

                {/* Condições Médicas */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Condições Médicas</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <BooleanRow label="Tem depressão?" value={questionnaire.tem_depressao} />
                        <BooleanRow label="Tem ansiedade?" value={questionnaire.tem_ansiedade} />
                        <BooleanRow label="Tem insônia?" value={questionnaire.tem_insonia} />
                        <BooleanRow label="Tem esquecimento?" value={questionnaire.tem_esquecimento} />
                        <BooleanRow label="Tem Alzheimer?" value={questionnaire.tem_alzheimer} />
                        <BooleanRow label="Tem Parkinson?" value={questionnaire.tem_parkinson} />
                    </div>
                </div>

                {/* Condições Crônicas */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Condições Crônicas</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <BooleanRow 
                            label="Tem hipertensão?" 
                            value={questionnaire.hipertensao}
                            conditionalValue={questionnaire.hipertensao_faz_uso}
                        />
                        <BooleanRow 
                            label="Tem diabetes?" 
                            value={questionnaire.diabetes}
                            conditionalValue={questionnaire.diabetes_faz_uso}
                        />
                    </div>
                </div>

                {/* Condições Comportamentais */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Condições Comportamentais</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <BooleanRow label="Dificuldade de aprendizado?" value={questionnaire.tem_dificuldade_aprendizado} />
                        <BooleanRow label="É hiperativo?" value={questionnaire.hiperativo} />
                        <BooleanRow label="É agressivo?" value={questionnaire.agressivo} />
                        <BooleanRow label="Tem autismo?" value={questionnaire.autismo} />
                        <BooleanRow label="Tem dificuldade para dormir?" value={questionnaire.tem_dificuldade_dormir} />
                    </div>
                </div>

                {/* Informações Profissionais */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Informações Profissionais</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Profissional que fez o Pedido" value={questionnaire.nome_profissional_pedido} />
                        <InfoRow label="Técnico/Médico do Exame" value={questionnaire.nome_tecnico_medico_exame} />
                    </div>
                </div>

                {/* Comentários */}
                {questionnaire.comentario && (
                    <div className="mb-2">
                        <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Comentários</h2>
                        <div className="px-2">
                            <div className="text-xs font-semibold text-gray-700 mb-0">Comentários</div>
                            <div className="text-xs text-gray-900 whitespace-pre-wrap" style={{ lineHeight: '1.3' }}>{questionnaire.comentario}</div>
                        </div>
                    </div>
                )}

                {/* Footer */}
                <div className="mt-2 pt-2 text-center" style={{ borderTop: '1px solid #d1d5db', position: 'absolute', bottom: '10mm', left: '10mm', right: '10mm' }}>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>
                        Criado em: {new Date(questionnaire.created_at).toLocaleDateString('pt-BR')} {new Date(questionnaire.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>Por: {questionnaire.creator?.name || 'Sistema'}</p>
                </div>
            </div>
        );
    }

    // Potencial Evocado
    if (type === 'potencial') {
        return (
            <div className="bg-white" style={{ width: '210mm', height: '297mm', padding: '6mm 8mm 8mm 8mm', fontFamily: 'Arial, sans-serif', fontSize: '10px' }}>
                {/* Header */}
                <div className={QT.potencial.header + " px-3 py-1 mb-1.5"} style={{ borderRadius: '3px' }}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-sm font-bold mb-0" style={{ lineHeight: '1.2' }}>Sistema de Questionários - Potencial Evocado</h1>
                            <p className="text-xs mb-0" style={{ lineHeight: '1.2' }}>Potencial Evocado Auditivo e Visual</p>
                        </div>
                        <div className="text-right" style={{ fontSize: '9px', lineHeight: '1.2' }}>
                            <div>Data: {new Date().toLocaleDateString('pt-BR')}</div>
                            <div>Paciente: {questionnaire.nome}</div>
                        </div>
                    </div>
                </div>

                {/* Dados Básicos */}
                <div className="mb-1.5">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-0.5 mb-1" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Dados Básicos</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome" value={questionnaire.nome} />
                        <InfoRow label="RG ou CPF" value={questionnaire.rg} />
                        <InfoRow label="Data de Nascimento" value={formatDateShort(questionnaire.data_nascimento)} />
                        <InfoRow label="Idade" value={questionnaire.idade} />
                        {sees('peso') && <InfoRow label="Peso" value={questionnaire.peso} />}
                        {sees('altura') && <InfoRow label="Altura" value={questionnaire.altura} />}
                        <InfoRow label="Data do Exame" value={formatDateShort(questionnaire.data_exame)} />
                        <InfoRow label="Sexo" value={questionnaire.sexo} />
                        <InfoRow label="Solicitante" value={questionnaire.solicitante} />
                        <InfoRow label="Clínica" value={questionnaire.clinica} />
                        {sees('hiperativo') && <BooleanRow label="É hiperativo?" value={questionnaire.hiperativo} />}
                    </div>
                </div>

                {/* Potencial Evocado Auditivo */}
                <div className="mb-1.5">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-0.5 mb-1" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Potencial Evocado Auditivo</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <BooleanRow label="Tem zumbido no ouvido?" value={questionnaire.tem_zumbido_ouvido} />
                        <BooleanRow label="Passou com fonoaudiólogo?" value={questionnaire.passou_fonoaudiologo} conditionalValue={questionnaire.fonoaudiologo_motivo} />
                        <BooleanRow label="Passou com otorrino?" value={questionnaire.passou_otorrino} conditionalValue={questionnaire.otorrino_motivo} />
                        <BooleanRow label="Passa com neurologista?" value={questionnaire.passa_neurologista} conditionalValue={questionnaire.neurologista_motivo} />
                        <BooleanRow label="Passa com neuropediatra?" value={questionnaire.passa_neuropediatra} conditionalValue={questionnaire.neuropediatra_motivo} />
                        <BooleanRow label="Passa com psiquiatra?" value={questionnaire.passa_psiquiatra} conditionalValue={questionnaire.psiquiatra_motivo} />
                        <BooleanRow label="Tem retardo mental?" value={questionnaire.tem_retardo_mental} conditionalValue={questionnaire.retardo_mental_grau} />
                        <BooleanRow label="Tem paralisia cerebral?" value={questionnaire.tem_paralisia_cerebral} />
                        <BooleanRow label="Síndrome de Down?" value={questionnaire.sindrome_down} />
                        <BooleanRow label="Autismo?" value={questionnaire.autismo} />
                        <BooleanRow label="Cefaléa ou Enxaqueca?" value={questionnaire.cefaleia_enxaqueca} />
                        <BooleanRow label="Crise Convulsiva?" value={questionnaire.crise_convulsiva} />
                        <BooleanRow label="Desmaios?" value={questionnaire.desmaios} />
                        <BooleanRow label="Dificuldade na fala?" value={questionnaire.dificuldade_fala} />
                        <BooleanRow label="Déficit de atenção?" value={questionnaire.deficit_atencao} />
                        <BooleanRow label="Dificuldade de aprendizado?" value={questionnaire.dificuldade_aprendizado} />
                        <BooleanRow label="Familiar com perda auditiva?" value={questionnaire.familiar_perda_auditiva} conditionalValue={questionnaire.familiar_perda_auditiva_quem} />
                        <BooleanRow label="Teste da orelhinha alterado?" value={questionnaire.teste_orelhinha_alterado} />
                        <InfoRow label="Meses de gestação" value={questionnaire.gestacao_meses || 'N/A'} />
                        <BooleanRow label="Teve perda da audição?" value={questionnaire.teve_perda_audicao} conditionalValue={questionnaire.perda_audicao_ouvido} />
                        <BooleanRow label="Teve infecção de ouvido?" value={questionnaire.teve_infeccao_ouvido} />
                        <BooleanRow label="Teve trauma de ouvido?" value={questionnaire.teve_trauma_ouvido} />
                        <BooleanRow label="Tem labirintite ou tontura?" value={questionnaire.tem_labirintite_tontura_auditivo} />
                    </div>
                </div>

                {/* Potencial Evocado Visual */}
                <div className="mb-1.5">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-0.5 mb-1" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Potencial Evocado Visual</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <BooleanRow label="Já teve AVC?" value={questionnaire.teve_avc} conditionalValue={questionnaire.avc_quando} />
                        <BooleanRow label="Dificuldade para olhar fixo?" value={questionnaire.dificuldade_olhar_fixo} />
                        <BooleanRow label="Tem diplopia (visão dupla)?" value={questionnaire.tem_diplopia} />
                        <BooleanRow label="Passou com oftalmologista?" value={questionnaire.passou_oftalmologista} conditionalValue={questionnaire.oftalmologista_motivo} />
                        <BooleanRow label="Tem patologia no olho?" value={questionnaire.tem_patologia_olho} conditionalValue={questionnaire.patologia_olho_detalhes} />
                        <BooleanRow label="Usa óculos?" value={questionnaire.usa_oculos} conditionalValue={questionnaire.grau_oculos} />
                        <BooleanRow label="Cefaléia?" value={questionnaire.cefaleia_visual} />
                        <BooleanRow label="Tem enxaqueca?" value={questionnaire.tem_enxaqueca_visual} />
                        <BooleanRow label="Se incomoda com claridade?" value={questionnaire.incomoda_claridade} />
                        <BooleanRow label="Vê pontinhos coloridos?" value={questionnaire.ve_pontinhos_coloridos} />
                        <BooleanRow label="Tem alucinações visuais?" value={questionnaire.tem_alucinacoes_visuais} />
                        <BooleanRow label="Tem labirintite ou tontura?" value={questionnaire.tem_labirintite_tontura_visual} />
                    </div>
                </div>

                {/* Condições Gerais */}
                <div className="mb-1.5">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-0.5 mb-1" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Condições Gerais</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <BooleanRow label="Tem hipertensão arterial?" value={questionnaire.tem_hipertensao_auditivo || questionnaire.tem_hipertensao_visual} />
                        <BooleanRow label="Tem diabetes?" value={questionnaire.tem_diabetes_auditivo || questionnaire.tem_diabetes_visual} />
                    </div>
                </div>

                {/* Observações */}
                {questionnaire.observacoes && (
                    <div className="mb-1.5">
                        <h2 className="text-xs font-bold bg-gray-200 px-2 py-0.5 mb-1" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Observações</h2>
                        <div className="px-2">
                            <div className="text-xs text-gray-900 whitespace-pre-wrap" style={{ lineHeight: '1.3' }}>{questionnaire.observacoes}</div>
                        </div>
                    </div>
                )}

                {/* Footer */}
                <div className="mt-1 pt-1 text-center" style={{ borderTop: '1px solid #d1d5db', position: 'absolute', bottom: '8mm', left: '8mm', right: '8mm' }}>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>
                        Criado em: {new Date(questionnaire.created_at).toLocaleDateString('pt-BR')} {new Date(questionnaire.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>Por: {questionnaire.creator?.name || 'Sistema'}</p>
                </div>
            </div>
        );
    }

    // Electroneuromiografia
    if (type === 'electroneuromiografia') {
        return (
            <div className="bg-white" style={{ width: '210mm', height: '297mm', padding: '7mm', fontFamily: 'Arial, sans-serif', fontSize: '9px' }}>
                {/* Header */}
                <div className={QT.electroneuromiografia.header + " px-2 py-1 mb-2"} style={{ borderRadius: '3px' }}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-xs font-bold mb-0" style={{ lineHeight: '1.2' }}>Sistema de Questionários - ENMG</h1>
                            <p style={{ fontSize: '8px', marginBottom: 0, lineHeight: '1.2' }}>Electroneuromiografia</p>
                        </div>
                        <div className="text-right" style={{ fontSize: '8px', lineHeight: '1.2' }}>
                            <div>Data: {new Date().toLocaleDateString('pt-BR')}</div>
                            <div>Paciente: {questionnaire.nome}</div>
                        </div>
                    </div>
                </div>

                {/* Dados Básicos */}
                <div className="mb-1">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-0.5 mb-1" style={{ borderRadius: '2px', lineHeight: '1.2' }}>Dados Básicos</h2>
                    <div className="grid grid-cols-3 gap-x-3 gap-y-0 px-2">
                        <InfoRow label="Nome" value={questionnaire.nome} />
                        <InfoRow label="RG" value={questionnaire.rg} />
                        <InfoRow label="Sexo" value={questionnaire.sexo} />
                        <InfoRow label="Data Nasc." value={formatDateShort(questionnaire.data_nascimento)} />
                        <InfoRow label="Idade" value={questionnaire.idade} />
                        <InfoRow label="Data Exame" value={formatDateShort(questionnaire.data_exame)} />
                        <InfoRow label="Peso" value={questionnaire.peso || 'N/A'} />
                        <InfoRow label="Altura" value={questionnaire.altura || 'N/A'} />
                        <InfoRow label="Solicitante" value={questionnaire.solicitante} />
                        <InfoRow label="Clínica" value={questionnaire.clinica} />
                        <InfoRow label="Equipe" value={questionnaire.team?.name} />
                        <InfoRow label="Tipos Exame" value={questionnaire.tipos_exame?.join(', ') || 'N/A'} />
                    </div>
                </div>

                {/* Informação Adicional */}
                <div className="mb-1">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-0.5 mb-1" style={{ borderRadius: '2px', lineHeight: '1.2' }}>Informações Clínicas</h2>
                    <div className="grid grid-cols-3 gap-x-3 gap-y-0 px-2">
                        <BooleanRow label="Primeira vez exame" value={questionnaire.primeira_vez_exame} />
                        <BooleanRow label="Diabético" value={questionnaire.diabetico} />
                        <BooleanRow label="Diabético tratamento" value={questionnaire.diabetico_tratamento} />
                        <BooleanRow label="Tomando medicamentos" value={questionnaire.tomando_medicamentos} conditionalValue={questionnaire.medicamentos_detalhes} />
                        <BooleanRow label="Teve COVID" value={questionnaire.teve_covid} />
                        <BooleanRow label="Teve AVC" value={questionnaire.teve_avc} conditionalValue={questionnaire.avc_tipo && questionnaire.avc_quando ? `${questionnaire.avc_tipo} - ${questionnaire.avc_quando}` : questionnaire.avc_tipo || questionnaire.avc_quando} />
                        <BooleanRow label="Dor coluna" value={questionnaire.dor_coluna} conditionalValue={questionnaire.areas_coluna?.join(', ')} />
                        <BooleanRow label="Trabalha" value={questionnaire.trabalha} conditionalValue={questionnaire.tipo_trabalho} />
                        <BooleanRow label="Teve fraturas" value={questionnaire.teve_fraturas} conditionalValue={questionnaire.fraturas_regiao} />
                        <BooleanRow label="Quimioterapia" value={questionnaire.faz_quimioterapia} />
                        <BooleanRow label="Radioterapia" value={questionnaire.faz_radioterapia} />
                        <BooleanRow label="Hemodiálise" value={questionnaire.faz_hemodialise} />
                        <BooleanRow label="Marcapasso" value={questionnaire.tem_marcapasso} />
                        <BooleanRow label="Processo infeccioso" value={questionnaire.processo_infeccioso} conditionalValue={questionnaire.processo_infeccioso_detalhes} />
                        <BooleanRow label="Consome álcool" value={questionnaire.consome_alcool} conditionalValue={questionnaire.alcool_frequencia} />
                        <BooleanRow label="Usa drogas" value={questionnaire.usa_drogas} conditionalValue={questionnaire.drogas_quais} />
                    </div>
                </div>

                {/* Membros Superiores */}
                <div className="mb-1">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-0.5 mb-1" style={{ borderRadius: '2px', lineHeight: '1.2' }}>Membros Superiores</h2>
                    <div className="grid grid-cols-4 gap-x-2 gap-y-0 px-2">
                        <BooleanRow label="Dor braços" value={questionnaire.ms_dor_bracos} />
                        <BooleanRow label="Dor ombros" value={questionnaire.ms_dor_comeca_ombros} />
                        <BooleanRow label="Dor mãos" value={questionnaire.ms_dor_maos} />
                        <BooleanRow label="Dor mais de" value={questionnaire.ms_dor_mais_de ? true : false} conditionalValue={questionnaire.ms_dor_mais_de} />
                        <BooleanRow label="Formig. braços" value={questionnaire.ms_formigamento_bracos} />
                        <BooleanRow label="Formig. ombros" value={questionnaire.ms_formigamento_comeca_ombros} />
                        <BooleanRow label="Formig. mãos" value={questionnaire.ms_formigamento_maos} />
                        <BooleanRow label="Dormência braços" value={questionnaire.ms_dormencia_bracos} />
                        <BooleanRow label="Dorm. ombros" value={questionnaire.ms_dormencia_comeca_ombros} />
                        <BooleanRow label="Dorm. mãos" value={questionnaire.ms_dormencia_maos} />
                        <BooleanRow label="Tremores braços" value={questionnaire.ms_tremores_bracos} />
                        <BooleanRow label="Tremores mãos" value={questionnaire.ms_tremores_maos} />
                        <BooleanRow label="Polegar treme" value={questionnaire.ms_polegar_treme} />
                        <BooleanRow label="Fraqueza braços" value={questionnaire.ms_fraqueza_bracos} />
                        <BooleanRow label="Fraqueza mãos" value={questionnaire.ms_fraqueza_maos} />
                        <BooleanRow label="Fadiga falar" value={questionnaire.ms_fadiga_falar} />
                        <BooleanRow label="Perda peso" value={questionnaire.ms_perda_peso} />
                        <BooleanRow label="Queimação" value={questionnaire.ms_queimacao} />
                        <BooleanRow label="Cãibra" value={questionnaire.ms_caibra} />
                        <BooleanRow label="Membro afetado" value={questionnaire.ms_membro_mais_afetado ? true : false} conditionalValue={questionnaire.ms_membro_mais_afetado} />
                    </div>
                </div>

                {/* Membros Inferiores */}
                <div className="mb-1">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-0.5 mb-1" style={{ borderRadius: '2px', lineHeight: '1.2' }}>Membros Inferiores</h2>
                    <div className="grid grid-cols-4 gap-x-2 gap-y-0 px-2">
                        <BooleanRow label="Dor pernas" value={questionnaire.mi_dor_pernas} />
                        <BooleanRow label="Dor bacia" value={questionnaire.mi_dor_comeca_bacia} />
                        <BooleanRow label="Dor ciático" value={questionnaire.mi_dor_ciatico} />
                        <BooleanRow label="Dor pés" value={questionnaire.mi_dor_pes} />
                        <BooleanRow label="Formig. pernas" value={questionnaire.mi_formigamento_pernas} />
                        <BooleanRow label="Formig. bacia" value={questionnaire.mi_formigamento_comeca_bacia} />
                        <BooleanRow label="Formig. pés" value={questionnaire.mi_formigamento_pes} />
                        <BooleanRow label="Dormência pernas" value={questionnaire.mi_dormencia_pernas} />
                        <BooleanRow label="Dorm. bacia" value={questionnaire.mi_dormencia_comeca_bacia} />
                        <BooleanRow label="Dorm. pés" value={questionnaire.mi_dormencia_pes} />
                        <BooleanRow label="Tremores pernas" value={questionnaire.mi_tremores_pernas} />
                        <BooleanRow label="Tremores pés" value={questionnaire.mi_tremores_pes} />
                        <BooleanRow label="Fraqueza pernas" value={questionnaire.mi_fraqueza_pernas} />
                        <BooleanRow label="Fraqueza pés" value={questionnaire.mi_fraqueza_pes} />
                        <BooleanRow label="Fraq. ascendente" value={questionnaire.mi_fraqueza_ascendente} />
                        <BooleanRow label="Fadiga falar" value={questionnaire.mi_fadiga_falar} />
                        <BooleanRow label="Perda peso" value={questionnaire.mi_perda_peso} />
                        <BooleanRow label="Queimação" value={questionnaire.mi_queimacao} />
                        <BooleanRow label="Cãibra" value={questionnaire.mi_caibra} />
                        <BooleanRow label="Membro afetado" value={questionnaire.mi_membro_mais_afetado ? true : false} conditionalValue={questionnaire.mi_membro_mais_afetado} />
                    </div>
                </div>

                {/* Especialistas */}
                <div className="mb-1">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-0.5 mb-1" style={{ borderRadius: '2px', lineHeight: '1.2' }}>Especialistas Consultados</h2>
                    <div className="grid grid-cols-3 gap-x-3 gap-y-0 px-2">
                        <BooleanRow label="Reumatologista" value={questionnaire.consultou_reumatologista} conditionalValue={questionnaire.reumatologista_motivo} />
                        <BooleanRow label="Neurologista" value={questionnaire.consultou_neurologista} conditionalValue={questionnaire.neurologista_motivo} />
                        <BooleanRow label="Neurocirurgião" value={questionnaire.consultou_neurocirurgiao} conditionalValue={questionnaire.neurocirurgiao_motivo} />
                        <BooleanRow label="Dermatologista" value={questionnaire.consultou_dermatologista} conditionalValue={questionnaire.dermatologista_motivo} />
                        <BooleanRow label="Geriatra" value={questionnaire.consultou_geriatra} conditionalValue={questionnaire.geriatra_motivo} />
                        <BooleanRow label="Ortopedista" value={questionnaire.consultou_ortopedista} conditionalValue={questionnaire.ortopedista_motivo} />
                    </div>
                </div>

                {/* Observações */}
                {questionnaire.observacoes && (
                    <div className="mb-1">
                        <h2 className="text-xs font-bold bg-gray-200 px-2 py-0.5 mb-1" style={{ borderRadius: '2px', lineHeight: '1.2' }}>Observações</h2>
                        <div className="px-2">
                            <div style={{ fontSize: '8px', lineHeight: '1.3' }} className="text-gray-900 whitespace-pre-wrap">{questionnaire.observacoes}</div>
                        </div>
                    </div>
                )}

                {/* Footer */}
                <div className="mt-1 pt-1 text-center" style={{ borderTop: '1px solid #d1d5db', position: 'absolute', bottom: '7mm', left: '7mm', right: '7mm' }}>
                    <p className="mb-0" style={{ fontSize: '8px', lineHeight: '1.2', color: '#6b7280' }}>
                        Criado em: {new Date(questionnaire.created_at).toLocaleDateString('pt-BR')} • Por: {questionnaire.creator?.name || 'Sistema'}
                    </p>
                </div>
            </div>
        );
    }

    // Electroneuromiografia Facial
    if (type === 'electroneuromiografia-facial') {
        return (
            <div className="bg-white" style={{ width: '210mm', height: '297mm', padding: '10mm', fontFamily: 'Arial, sans-serif', fontSize: '11px' }}>
                {/* Header */}
                <div className={QT.electroneuromiografia_facial.header + " px-3 py-2 mb-3"} style={{ borderRadius: '3px' }}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-sm font-bold mb-0" style={{ lineHeight: '1.2' }}>Sistema de Questionários - ENMG Facial</h1>
                            <p className="text-xs mb-0" style={{ lineHeight: '1.2' }}>Electroneuromiografia Facial</p>
                        </div>
                        <div className="text-right" style={{ fontSize: '9px', lineHeight: '1.3' }}>
                            <div>Data de Exportação: {new Date().toLocaleDateString('pt-BR')} {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                            <div>Paciente: {questionnaire.nome}</div>
                        </div>
                    </div>
                </div>

                {/* Dados Básicos */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Dados Básicos</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome" value={questionnaire.nome} />
                        <InfoRow label="RG" value={questionnaire.rg} />
                        <InfoRow label="Data de Nascimento" value={formatDateShort(questionnaire.data_nascimento)} />
                        <InfoRow label="Idade" value={questionnaire.idade_calculada} />
                        <InfoRow label="Sexo" value={questionnaire.sexo} />
                        <InfoRow label="Data do Exame" value={formatDateShort(questionnaire.data_exame)} />
                        <InfoRow label="Solicitante" value={questionnaire.solicitante} />
                        <InfoRow label="Clínica" value={questionnaire.clinica} />
                        <InfoRow label="Equipe" value={questionnaire.team?.name} />
                    </div>
                </div>

                {/* Questionário Facial */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Questionário de Electroneuromiografia Facial</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <BooleanRow label="Tem dor na testa?" value={questionnaire.tem_dor_testa} />
                        <BooleanRow label="Dor nos olhos?" value={questionnaire.tem_dor_olhos} conditionalValue={questionnaire.dor_olhos_lado} />
                        <BooleanRow label="Dor na mandíbula?" value={questionnaire.tem_dor_mandibula} />
                        <BooleanRow label="Dor nos dentes (água gelada)?" value={questionnaire.tem_dor_dentes_agua_gelada} />
                        <BooleanRow label="Espasmos na face?" value={questionnaire.tem_espasmos_face} conditionalValue={questionnaire.espasmos_face_parte} />
                        <BooleanRow label="Aplicou Botox?" value={questionnaire.aplicou_botox} conditionalValue={questionnaire.botox_parte_face} />
                        <BooleanRow label="Implante dentário?" value={questionnaire.tem_implante_dentario} />
                        <BooleanRow label="Dores após implante?" value={questionnaire.tem_dores_apos_implante} />
                        <BooleanRow label="Teve paralisia facial?" value={questionnaire.teve_paralisia_facial} conditionalValue={questionnaire.paralisia_facial_vezes ? `${questionnaire.paralisia_facial_vezes} vezes` : null} />
                        <BooleanRow label="Parte da face paralisada?" value={questionnaire.tem_parte_face_paralisada} conditionalValue={questionnaire.parte_face_paralisada_qual} />
                        <BooleanRow label="Tem enxaqueca?" value={questionnaire.tem_enxaqueca} />
                        <BooleanRow label="Consegue sorrir normalmente?" value={questionnaire.consegue_sorrir_normalmente} />
                        <BooleanRow label="Pode comer normalmente?" value={questionnaire.pode_comer_normalmente} />
                        <BooleanRow label="Pode assoviar?" value={questionnaire.pode_assoviar} />
                        <BooleanRow label="Consegue encher bexiga?" value={questionnaire.consegue_encher_bexiga} />
                        <BooleanRow label="Infecção de ouvido repetida?" value={questionnaire.tem_infeccao_ouvido_repetidamente} />
                        <BooleanRow label="Diabético(a)?" value={questionnaire.diabetico} />
                        <BooleanRow label="Toma medicamento?" value={questionnaire.toma_medicamento} conditionalValue={questionnaire.medicamentos} />
                        {sees('teve_avc') && <BooleanRow label="Já teve AVC?" value={questionnaire.teve_avc} conditionalValue={questionnaire.avc_quando} />}
                    </div>
                </div>

                {/* Observações */}
                {questionnaire.observacoes && (
                    <div className="mb-2">
                        <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Observações</h2>
                        <p className="text-xs px-2 whitespace-pre-wrap" style={{ lineHeight: '1.3' }}>{questionnaire.observacoes}</p>
                    </div>
                )}

                {/* Footer */}
                <div className="mt-2 pt-2 text-center" style={{ borderTop: '1px solid #d1d5db', position: 'absolute', bottom: '10mm', left: '10mm', right: '10mm' }}>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>
                        Criado em: {new Date(questionnaire.created_at).toLocaleDateString('pt-BR')} {new Date(questionnaire.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>Por: {questionnaire.creator?.name || 'Sistema'}</p>
                </div>
            </div>
        );
    }

    // Avaliação do Equilíbrio (TUG + Berg)
    if (type === 'avaliacao-equilibrio') {
        const BERG_ITEMS = [
            { field: 'berg_sentado_para_pe', label: '1. Sentado para de pé' },
            { field: 'berg_permanecer_pe_sem_apoio', label: '2. Permanecer de pé sem apoio' },
            { field: 'berg_sentado_sem_apoio', label: '3. Sentado sem apoio dorsal' },
            { field: 'berg_pe_para_sentado', label: '4. De pé para sentado' },
            { field: 'berg_transferencias', label: '5. Transferências entre cadeiras' },
            { field: 'berg_pe_olhos_fechados', label: '6. De pé com olhos fechados' },
            { field: 'berg_pe_pes_juntos', label: '7. De pé com pés juntos' },
            { field: 'berg_alcance_anterior', label: '8. Alcance anterior com braço' },
            { field: 'berg_pegar_objeto_chao', label: '9. Pegar objeto do chão' },
            { field: 'berg_olhar_para_tras', label: '10. Olhar para trás (ombros)' },
            { field: 'berg_girar_360', label: '11. Girar 360 graus' },
            { field: 'berg_tocar_degrau', label: '12. Tocar degrau alternadamente' },
            { field: 'berg_posicao_tandem', label: '13. Posição de Tândem' },
            { field: 'berg_apoio_monopodal', label: '14. Apoio Monopodal' },
        ];

        return (
            <div className="bg-white" style={{ width: '210mm', height: '297mm', padding: '8mm', fontFamily: 'Arial, sans-serif', fontSize: '9px' }}>
                {/* Header */}
                <div className={QT.equilibrio.header + " px-3 py-2 mb-2"} style={{ borderRadius: '3px' }}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-sm font-bold mb-0" style={{ lineHeight: '1.2' }}>Sistema de Questionários - Avaliação do Equilíbrio</h1>
                            <p className="text-xs mb-0" style={{ lineHeight: '1.2' }}>Equilíbrio Clínico e Risco de Quedas (TUG + Berg)</p>
                        </div>
                        <div className="text-right" style={{ fontSize: '9px', lineHeight: '1.3' }}>
                            <div>Data de Exportação: {new Date().toLocaleDateString('pt-BR')} {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                            <div>Paciente: {questionnaire.nome_completo}</div>
                        </div>
                    </div>
                </div>

                {/* Dados Básicos */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Dados Básicos</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome Completo" value={questionnaire.nome_completo} />
                        <InfoRow label="RG ou CPF" value={questionnaire.rg_ou_cpf} />
                        <InfoRow label="Data de Nascimento" value={formatDateShort(questionnaire.data_nascimento)} />
                        <InfoRow label="Idade" value={questionnaire.idade} />
                        <InfoRow label="Sexo" value={questionnaire.sexo} />
                        <InfoRow label="Data do Exame" value={formatDateShort(questionnaire.data_exame)} />
                        <InfoRow label="Clínica" value={questionnaire.clinica} />
                        <InfoRow label="Equipe" value={questionnaire.team?.name} />
                    </div>
                </div>

                {/* TUG */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Timed Up and Go (TUG)</h2>
                    <div className="px-2">
                        <InfoRow label="Tempo Registrado" value={questionnaire.tug_tempo_segundos ? `${questionnaire.tug_tempo_segundos} segundos` : 'Não informado'} />
                    </div>
                </div>

                {/* Escala de Berg */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Escala de Equilíbrio de Berg (BBS)</h2>
                    <div className="grid grid-cols-3 gap-x-4 gap-y-0 px-2">
                        {BERG_ITEMS.map((item) => (
                            <InfoRow key={item.field} label={item.label} value={`${questionnaire[item.field] ?? '-'} / 4`} />
                        ))}
                    </div>
                    <div className="px-2 mt-1">
                        <InfoRow label="Pontuação Total (Berg)" value={`${questionnaire.berg_total ?? '-'} / 56`} />
                    </div>
                </div>

                {/* Avaliação */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Avaliação</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome do Avaliador" value={questionnaire.nome_avaliador || 'Não informado'} />
                        <InfoRow label="CID" value={questionnaire.cid || 'Não informado'} />
                    </div>
                    {questionnaire.comentario && (
                        <div className="px-2 mt-1">
                            <div className="text-xs font-semibold text-gray-700 mb-0">Comentário</div>
                            <div className="text-xs text-gray-900 whitespace-pre-wrap" style={{ lineHeight: '1.3' }}>{questionnaire.comentario}</div>
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="mt-2 pt-2 text-center" style={{ borderTop: '1px solid #d1d5db', position: 'absolute', bottom: '8mm', left: '8mm', right: '8mm' }}>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>
                        Criado em: {new Date(questionnaire.created_at).toLocaleDateString('pt-BR')} {new Date(questionnaire.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>Por: {questionnaire.creator?.name || 'Sistema'}</p>
                </div>
            </div>
        );
    }

    // Rastreio Cognitivo (MoCA)
    if (type === 'rastreio-cognitivo') {
        return (
            <div className="bg-white" style={{ width: '210mm', height: '297mm', padding: '8mm', fontFamily: 'Arial, sans-serif', fontSize: '9px' }}>
                {/* Header */}
                <div className={QT.rastreio_cognitivo.header + " px-3 py-2 mb-2"} style={{ borderRadius: '3px' }}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-sm font-bold mb-0" style={{ lineHeight: '1.2' }}>Sistema de Questionários - Rastreio Cognitivo</h1>
                            <p className="text-xs mb-0" style={{ lineHeight: '1.2' }}>Protocolo de Rastreio Cognitivo em Consulta (MoCA)</p>
                        </div>
                        <div className="text-right" style={{ fontSize: '9px', lineHeight: '1.3' }}>
                            <div>Data de Exportação: {new Date().toLocaleDateString('pt-BR')} {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                            <div>Paciente: {questionnaire.nome_completo}</div>
                        </div>
                    </div>
                </div>

                {/* Dados Básicos */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Dados Básicos</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome Completo" value={questionnaire.nome_completo} />
                        <InfoRow label="RG ou CPF" value={questionnaire.rg_ou_cpf} />
                        <InfoRow label="Data de Nascimento" value={formatDateShort(questionnaire.data_nascimento)} />
                        <InfoRow label="Idade" value={questionnaire.idade} />
                        <InfoRow label="Sexo" value={questionnaire.sexo} />
                        <InfoRow label="Data do Exame" value={formatDateShort(questionnaire.data_exame)} />
                        <InfoRow label="Clínica" value={questionnaire.clinica} />
                        <InfoRow label="Equipe" value={questionnaire.team?.name} />
                    </div>
                </div>

                {/* Folha de Pontuação */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Folha de Pontuação Rápida (MoCA)</h2>
                    <div className="grid grid-cols-4 gap-x-4 gap-y-0 px-2">
                        <InfoRow label="Visoespacial / Executiva" value={`${questionnaire.pontuacao_visoespacial ?? '-'} / 5`} />
                        <InfoRow label="Nomeação" value={`${questionnaire.pontuacao_nomeacao ?? '-'} / 3`} />
                        <InfoRow label="Atenção" value={`${questionnaire.pontuacao_atencao ?? '-'} / 6`} />
                        <InfoRow label="Linguagem" value={`${questionnaire.pontuacao_linguagem ?? '-'} / 3`} />
                        <InfoRow label="Abstração" value={`${questionnaire.pontuacao_abstracao ?? '-'} / 2`} />
                        <InfoRow label="Evocação Tardia" value={`${questionnaire.pontuacao_evocacao_tardia ?? '-'} / 5`} />
                        <InfoRow label="Orientação" value={`${questionnaire.pontuacao_orientacao ?? '-'} / 6`} />
                        <InfoRow label="Ajuste de Escolaridade" value={questionnaire.ajuste_escolaridade ? '+1 pt' : '—'} />
                    </div>
                    <div className="px-2 mt-1">
                        <InfoRow label="Pontuação Total" value={`${questionnaire.pontuacao_total ?? '-'} / 30`} />
                    </div>
                </div>

                {/* Avaliação */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Avaliação</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome do Avaliador" value={questionnaire.nome_avaliador || 'Não informado'} />
                        <InfoRow label="CID" value={questionnaire.cid || 'Não informado'} />
                    </div>
                    {questionnaire.comentario && (
                        <div className="px-2 mt-1">
                            <div className="text-xs font-semibold text-gray-700 mb-0">Comentário</div>
                            <div className="text-xs text-gray-900 whitespace-pre-wrap" style={{ lineHeight: '1.3' }}>{questionnaire.comentario}</div>
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="mt-2 pt-2 text-center" style={{ borderTop: '1px solid #d1d5db', position: 'absolute', bottom: '8mm', left: '8mm', right: '8mm' }}>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>
                        Criado em: {new Date(questionnaire.created_at).toLocaleDateString('pt-BR')} {new Date(questionnaire.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>Por: {questionnaire.creator?.name || 'Sistema'}</p>
                </div>
            </div>
        );
    }

    // Mini Exame do Estado Mental (MEEM)
    if (type === 'mini-exame-mental') {
        return (
            <div className="bg-white" style={{ width: '210mm', height: '297mm', padding: '8mm', fontFamily: 'Arial, sans-serif', fontSize: '9px' }}>
                {/* Header */}
                <div className={QT.mini_exame_mental.header + " px-3 py-2 mb-2"} style={{ borderRadius: '3px' }}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-sm font-bold mb-0" style={{ lineHeight: '1.2' }}>Sistema de Questionários - Mini Exame do Estado Mental</h1>
                            <p className="text-xs mb-0" style={{ lineHeight: '1.2' }}>Protocolo de Rastreio Cognitivo Breve (MEEM)</p>
                        </div>
                        <div className="text-right" style={{ fontSize: '9px', lineHeight: '1.3' }}>
                            <div>Data de Exportação: {new Date().toLocaleDateString('pt-BR')} {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                            <div>Paciente: {questionnaire.nome_completo}</div>
                        </div>
                    </div>
                </div>

                {/* Dados Básicos */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Dados Básicos</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome Completo" value={questionnaire.nome_completo} />
                        <InfoRow label="RG ou CPF" value={questionnaire.rg_ou_cpf} />
                        <InfoRow label="Data de Nascimento" value={formatDateShort(questionnaire.data_nascimento)} />
                        <InfoRow label="Idade" value={questionnaire.idade} />
                        <InfoRow label="Sexo" value={questionnaire.sexo} />
                        <InfoRow label="Data do Exame" value={formatDateShort(questionnaire.data_exame)} />
                        <InfoRow label="Clínica" value={questionnaire.clinica} />
                        <InfoRow label="Equipe" value={questionnaire.team?.name} />
                        <InfoRow label="Escolaridade" value={questionnaire.escolaridade || 'Não informado'} />
                    </div>
                </div>

                {/* Folha de Pontuação */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Folha de Pontuação (MEEM)</h2>
                    <div className="grid grid-cols-4 gap-x-4 gap-y-0 px-2">
                        <InfoRow label="Orientação Temporal" value={`${questionnaire.pontuacao_orientacao_temporal ?? '-'} / 5`} />
                        <InfoRow label="Orientação Espacial" value={`${questionnaire.pontuacao_orientacao_espacial ?? '-'} / 5`} />
                        <InfoRow label="Registro" value={`${questionnaire.pontuacao_registro ?? '-'} / 3`} />
                        <InfoRow label="Atenção e Cálculo" value={`${questionnaire.pontuacao_atencao_calculo ?? '-'} / 5`} />
                        <InfoRow label="Evocação" value={`${questionnaire.pontuacao_evocacao ?? '-'} / 3`} />
                        <InfoRow label="Linguagem" value={`${questionnaire.pontuacao_linguagem ?? '-'} / 8`} />
                        <InfoRow label="Cópia do Desenho" value={`${questionnaire.pontuacao_desenho ?? '-'} / 1`} />
                    </div>
                    <div className="px-2 mt-1">
                        <InfoRow label="Pontuação Total" value={`${questionnaire.pontuacao_total ?? '-'} / 30`} />
                    </div>
                </div>

                {/* Avaliação */}
                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Avaliação</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome do Avaliador" value={questionnaire.nome_avaliador || 'Não informado'} />
                        <InfoRow label="CID" value={questionnaire.cid || 'Não informado'} />
                    </div>
                    {questionnaire.comentario && (
                        <div className="px-2 mt-1">
                            <div className="text-xs font-semibold text-gray-700 mb-0">Comentário</div>
                            <div className="text-xs text-gray-900 whitespace-pre-wrap" style={{ lineHeight: '1.3' }}>{questionnaire.comentario}</div>
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="mt-2 pt-2 text-center" style={{ borderTop: '1px solid #d1d5db', position: 'absolute', bottom: '8mm', left: '8mm', right: '8mm' }}>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>
                        Criado em: {new Date(questionnaire.created_at).toLocaleDateString('pt-BR')} {new Date(questionnaire.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>Por: {questionnaire.creator?.name || 'Sistema'}</p>
                </div>
            </div>
        );
    }

    // TDAH Adulto (ASRS-18)
    if (type === 'tdah-adulto') {
        const SCALE = {
            0: 'Nunca',
            1: 'Raramente',
            2: 'Algumas vezes',
            3: 'Frequentemente',
            4: 'Muito frequentemente',
        };
        const PARTE_A = [
            'Erros por falta de atenção em projetos chatos ou difíceis?',
            'Dificuldade para manter a atenção em trabalho chato ou repetitivo?',
            'Dificuldade para se concentrar no que as pessoas dizem?',
            'Deixa um projeto pela metade depois de já ter feito as partes mais difíceis?',
            'Dificuldade de fazer um trabalho que exige organização?',
            'Evita ou adia o início de tarefas que exigem muita concentração?',
            'Coloca as coisas fora do lugar ou tem dificuldade de encontrá-las?',
            'Se distrai com atividades ou barulho ao redor?',
            'Dificuldade para lembrar de compromissos ou obrigações?',
        ];
        const PARTE_B = [
            'Fica se mexendo na cadeira quando precisa ficar sentado(a) por muito tempo?',
            'Se levanta da cadeira em situações onde deveria ficar sentado(a)?',
            'Se sente inquieto(a) ou agitado(a)?',
            'Dificuldade para sossegar e relaxar no tempo livre?',
            'Se sente ativo(a) demais, "com um motor ligado"?',
            'Fala demais em situações sociais?',
            'Termina as frases das pessoas antes delas?',
            'Dificuldade para esperar sua vez?',
            'Interrompe os outros quando estão ocupados?',
        ];
        const respScala = (lista, respostas) => (
            <ul className="list-none pl-0" style={{ fontSize: '9px' }}>
                {lista.map((p, idx) => (
                    <li key={idx} className="flex justify-between gap-2 py-0.5" style={{ borderBottom: '1px solid #e5e7eb' }}>
                        <span>{idx + 1}. {p}</span>
                        <span className="font-semibold flex-shrink-0">{SCALE[respostas?.[idx]] ?? '-'}</span>
                    </li>
                ))}
            </ul>
        );
        return (
            <div className="bg-white" style={{ width: '210mm', height: '297mm', padding: '10mm', fontFamily: 'Arial, sans-serif', fontSize: '10px' }}>
                <div className={QT.tdah_adulto.header + " px-3 py-2 mb-3"} style={{ borderRadius: '3px' }}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-sm font-bold mb-0" style={{ lineHeight: '1.2' }}>Sistema de Questionários - TDAH</h1>
                            <p className="text-xs mb-0" style={{ lineHeight: '1.2' }}>TDAH Adulto (ASRS-18)</p>
                        </div>
                        <div className="text-right" style={{ fontSize: '9px', lineHeight: '1.3' }}>
                            <div>Data de Exportação: {new Date().toLocaleDateString('pt-BR')} {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                            <div>Paciente: {questionnaire.nome_completo}</div>
                        </div>
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Dados Básicos</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome Completo" value={questionnaire.nome_completo} />
                        <InfoRow label="Sexo" value={questionnaire.sexo} />
                        <InfoRow label="Data de Nascimento" value={formatDateShort(questionnaire.data_nascimento)} />
                        <InfoRow label="Idade" value={questionnaire.idade} />
                        <InfoRow label="RG" value={questionnaire.rg || '-'} />
                        <InfoRow label="Peso / Altura" value={`${questionnaire.peso ?? '-'} kg / ${questionnaire.altura ?? '-'} cm`} />
                        <InfoRow label="Clínica" value={questionnaire.clinica || '-'} />
                        <InfoRow label="Data do Exame" value={formatDateShort(questionnaire.data_exame)} />
                        <InfoRow label="Solicitante" value={questionnaire.solicitante || '-'} />
                        <InfoRow label="Equipe" value={questionnaire.team?.name} />
                        <InfoRow label="CID" value={questionnaire.cid || '-'} />
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Parte A — Desatenção</h2>
                    <div className="px-2">{respScala(PARTE_A, questionnaire.parte_a_respostas)}</div>
                    <div className="px-2 mt-1"><InfoRow label="Parte A — Total" value={`${questionnaire.parte_a_total ?? '-'} / 36`} /></div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Parte B — Hiperatividade/Impulsividade</h2>
                    <div className="px-2">{respScala(PARTE_B, questionnaire.parte_b_respostas)}</div>
                    <div className="px-2 mt-1"><InfoRow label="Parte B — Total" value={`${questionnaire.parte_b_total ?? '-'} / 36`} /></div>
                </div>

                {questionnaire.comentario && (
                    <div className="mb-2">
                        <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Observações</h2>
                        <div className="px-2">
                            <div className="text-xs text-gray-900 whitespace-pre-wrap" style={{ lineHeight: '1.3' }}>{questionnaire.comentario}</div>
                        </div>
                    </div>
                )}

                <div className="mt-2 pt-2 text-center" style={{ borderTop: '1px solid #d1d5db', position: 'absolute', bottom: '10mm', left: '10mm', right: '10mm' }}>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>
                        Criado em: {new Date(questionnaire.created_at).toLocaleDateString('pt-BR')} {new Date(questionnaire.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>Por: {questionnaire.creator?.name || 'Sistema'}</p>
                </div>
            </div>
        );
    }

    // TDAH Infantil (SNAP-IV)
    if (type === 'tdah-infantil') {
        const SCALE = {
            0: 'Nunca',
            1: 'Raramente',
            2: 'Algumas vezes',
            3: 'Frequentemente',
            4: 'Muito frequentemente',
        };
        const PARTE_1 = [
            'Erra atividades porque não presta atenção nos detalhes?',
            'Dificuldade para manter a atenção em tarefas, brincadeiras ou outras atividades?',
            'Parece não escutar quando alguém fala diretamente com ela?',
            'Começa uma tarefa, mas não consegue terminar ou não segue as instruções até o fim?',
            'Dificuldade para organizar os materiais ou a rotina?',
            'Evita ou reclama de atividades que exigem pensar ou se concentrar por muito tempo?',
            'Perde ou esquece onde colocou objetos importantes?',
            'Se distrai facilmente com barulhos, pessoas ou qualquer coisa ao redor?',
            'Esquece compromissos, recados ou tarefas do dia a dia?',
        ];
        const PARTE_2 = [
            'Mexe muito as mãos, os pés ou fica inquieta quando está sentada?',
            'Levanta da cadeira quando deveria permanecer sentada?',
            'Corre, sobe em móveis ou se movimenta demais em momentos em que deveria ficar calma?',
            'Dificuldade para brincar ou fazer atividades tranquilas?',
            'Parece estar sempre agitada, "ligada no máximo"?',
            'Fala mais do que o esperado?',
            'Responde antes da pergunta terminar ou interrompe a resposta dos outros?',
            'Dificuldade para esperar sua vez em filas, jogos ou conversas?',
            'Costuma interromper conversas, brincadeiras ou se intrometer nas atividades dos outros?',
        ];
        const respScala = (lista, respostas) => (
            <ul className="list-none pl-0" style={{ fontSize: '9px' }}>
                {lista.map((p, idx) => (
                    <li key={idx} className="flex justify-between gap-2 py-0.5" style={{ borderBottom: '1px solid #e5e7eb' }}>
                        <span>{idx + 1}. {p}</span>
                        <span className="font-semibold flex-shrink-0">{SCALE[respostas?.[idx]] ?? '-'}</span>
                    </li>
                ))}
            </ul>
        );
        return (
            <div className="bg-white" style={{ width: '210mm', height: '297mm', padding: '10mm', fontFamily: 'Arial, sans-serif', fontSize: '10px' }}>
                <div className={QT.tdah_infantil.header + " px-3 py-2 mb-3"} style={{ borderRadius: '3px' }}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-sm font-bold mb-0" style={{ lineHeight: '1.2' }}>Sistema de Questionários - TDAH</h1>
                            <p className="text-xs mb-0" style={{ lineHeight: '1.2' }}>TDAH Infantil (SNAP-IV)</p>
                        </div>
                        <div className="text-right" style={{ fontSize: '9px', lineHeight: '1.3' }}>
                            <div>Data de Exportação: {new Date().toLocaleDateString('pt-BR')} {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                            <div>Paciente: {questionnaire.nome_completo}</div>
                        </div>
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Dados Básicos</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome Completo" value={questionnaire.nome_completo} />
                        <InfoRow label="Sexo" value={questionnaire.sexo} />
                        <InfoRow label="Data de Nascimento" value={formatDateShort(questionnaire.data_nascimento)} />
                        <InfoRow label="Idade" value={questionnaire.idade} />
                        <InfoRow label="RG/CPF" value={questionnaire.rg_ou_cpf || '-'} />
                        <InfoRow label="Peso / Altura" value={`${questionnaire.peso ?? '-'} kg / ${questionnaire.altura ?? '-'} cm`} />
                        <InfoRow label="Clínica" value={questionnaire.clinica || '-'} />
                        <InfoRow label="Data do Exame" value={formatDateShort(questionnaire.data_exame)} />
                        <InfoRow label="Solicitante" value={questionnaire.solicitante || '-'} />
                        <InfoRow label="Equipe" value={questionnaire.team?.name} />
                        <InfoRow label="CID" value={questionnaire.cid || '-'} />
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Parte I — Desatenção</h2>
                    <div className="px-2">{respScala(PARTE_1, questionnaire.parte_1_respostas)}</div>
                    <div className="px-2 mt-1"><InfoRow label="Parte I — Total" value={`${questionnaire.parte_1_total ?? '-'} / 36`} /></div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Parte II — Hiperatividade/Impulsividade</h2>
                    <div className="px-2">{respScala(PARTE_2, questionnaire.parte_2_respostas)}</div>
                    <div className="px-2 mt-1"><InfoRow label="Parte II — Total" value={`${questionnaire.parte_2_total ?? '-'} / 36`} /></div>
                </div>

                {questionnaire.comentario && (
                    <div className="mb-2">
                        <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Observações</h2>
                        <div className="px-2">
                            <div className="text-xs text-gray-900 whitespace-pre-wrap" style={{ lineHeight: '1.3' }}>{questionnaire.comentario}</div>
                        </div>
                    </div>
                )}

                <div className="mt-2 pt-2 text-center" style={{ borderTop: '1px solid #d1d5db', position: 'absolute', bottom: '10mm', left: '10mm', right: '10mm' }}>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>
                        Criado em: {new Date(questionnaire.created_at).toLocaleDateString('pt-BR')} {new Date(questionnaire.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>Por: {questionnaire.creator?.name || 'Sistema'}</p>
                </div>
            </div>
        );
    }

    // Dinamômetro (Força de Preensão Manual)
    if (type === 'dinamometro') {
        const CONTEXTO_LABELS = {
            neurologico: 'Neurológico',
            ortopedico: 'Ortopédico',
            geriatrico: 'Geriátrico',
            pediatrico: 'Pediátrico',
        };
        const boolVal = (v) => (v ? 'Sim' : 'Não');
        return (
            <div className="bg-white" style={{ width: '210mm', height: '297mm', padding: '10mm', fontFamily: 'Arial, sans-serif', fontSize: '10px' }}>
                <div className={QT.dinamometro.header + " px-3 py-2 mb-3"} style={{ borderRadius: '3px' }}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-sm font-bold mb-0" style={{ lineHeight: '1.2' }}>Sistema de Questionários - Dinamômetro</h1>
                            <p className="text-xs mb-0" style={{ lineHeight: '1.2' }}>Força de Preensão Manual</p>
                        </div>
                        <div className="text-right" style={{ fontSize: '9px', lineHeight: '1.3' }}>
                            <div>Data de Exportação: {new Date().toLocaleDateString('pt-BR')} {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                            <div>Paciente: {questionnaire.nome_completo}</div>
                        </div>
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Dados Básicos</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome Completo" value={questionnaire.nome_completo} />
                        <InfoRow label="Sexo" value={questionnaire.sexo} />
                        <InfoRow label="Data de Nascimento" value={formatDateShort(questionnaire.data_nascimento)} />
                        <InfoRow label="Idade" value={questionnaire.idade} />
                        <InfoRow label="Peso / Altura" value={`${questionnaire.peso ?? '-'} kg / ${questionnaire.altura ?? '-'} cm`} />
                        <InfoRow label="Dominância" value={questionnaire.dominancia || '-'} />
                        <InfoRow label="Profissão" value={questionnaire.profissao || '-'} />
                        <InfoRow label="Diagnóstico Principal" value={questionnaire.diagnostico_principal || '-'} />
                        <InfoRow label="Clínica" value={questionnaire.clinica || '-'} />
                        <InfoRow label="Data do Exame" value={formatDateShort(questionnaire.data_exame)} />
                        <InfoRow label="Equipe" value={questionnaire.team?.name} />
                        <InfoRow label="Contextos Clínicos" value={(questionnaire.contextos_clinicos || []).map((c) => CONTEXTO_LABELS[c] || c).join(', ') || '-'} />
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Histórico Clínico</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Doenças Crônicas" value={questionnaire.doencas_cronicas || '-'} />
                        <InfoRow label="Dor Atual (0-10)" value={questionnaire.dor_atual ?? '-'} />
                        <BooleanRow label="Fisioterapia recente?" value={questionnaire.fisioterapia_recente} />
                        <BooleanRow label="Lesão prévia/atual?" value={questionnaire.lesao_previa_atual} />
                        <BooleanRow label="Dor piora com força?" value={questionnaire.dor_piora_com_forca} />
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Padronização e Resultados (kgf)</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <div className="mb-1">
                            <span className="text-xs font-semibold text-gray-700">Mão Dominante</span>
                            <div className="text-xs text-gray-900">1ª: {questionnaire.mao_dominante_t1 ?? '-'} · 2ª: {questionnaire.mao_dominante_t2 ?? '-'} · 3ª: {questionnaire.mao_dominante_t3 ?? '-'}</div>
                            <div className="text-xs text-gray-900 font-bold">Média: {questionnaire.mao_dominante_media ?? '-'}</div>
                        </div>
                        <div className="mb-1">
                            <span className="text-xs font-semibold text-gray-700">Mão Não Dominante</span>
                            <div className="text-xs text-gray-900">1ª: {questionnaire.mao_nao_dominante_t1 ?? '-'} · 2ª: {questionnaire.mao_nao_dominante_t2 ?? '-'} · 3ª: {questionnaire.mao_nao_dominante_t3 ?? '-'}</div>
                            <div className="text-xs text-gray-900 font-bold">Média: {questionnaire.mao_nao_dominante_media ?? '-'}</div>
                        </div>
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Interpretação e Conduta</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Classificação" value={questionnaire.classificacao || '-'} />
                        <InfoRow label="Assimetria (%)" value={questionnaire.assimetria_percentual ?? '-'} />
                        <InfoRow label="Profissional" value={questionnaire.nome_avaliador || '-'} />
                        <InfoRow label="CREFITO/CRM" value={questionnaire.crefito_crm || '-'} />
                    </div>
                    {questionnaire.conclusao && (
                        <div className="px-2 mt-1"><InfoRow label="Conclusão" value={questionnaire.conclusao} /></div>
                    )}
                    {questionnaire.conduta && (
                        <div className="px-2 mt-1"><InfoRow label="Conduta" value={questionnaire.conduta} /></div>
                    )}
                    {questionnaire.comentario && (
                        <div className="px-2 mt-1"><InfoRow label="Comentário" value={questionnaire.comentario} /></div>
                    )}
                </div>

                <div className="mt-2 pt-2 text-center" style={{ borderTop: '1px solid #d1d5db', position: 'absolute', bottom: '10mm', left: '10mm', right: '10mm' }}>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>
                        Criado em: {new Date(questionnaire.created_at).toLocaleDateString('pt-BR')} {new Date(questionnaire.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>Por: {questionnaire.creator?.name || 'Sistema'}</p>
                </div>
            </div>
        );
    }

    // Estesiometria (Avaliação Sensitiva)
    if (type === 'estesiometria') {
        const PRE_EXAM = [
            { field: 'dormencia_formigamento', label: 'Dormência, formigamento ou queimação nas mãos/pés' },
            { field: 'dificuldade_sentir_objetos', label: 'Dificuldade para sentir objetos com as mãos' },
            { field: 'feridas_sem_dor', label: 'Feridas nos pés sem sentir dor' },
            { field: 'diagnostico_diabetes_hanseniase', label: 'Diagnóstico de diabetes, hanseníase ou doença neurológica' },
            { field: 'cirurgia_fratura_recente', label: 'Cirurgia ou fratura recente nas regiões avaliadas' },
            { field: 'medicamentos_sistema_nervoso', label: 'Uso de medicamentos que afetam o sistema nervoso' },
        ];
        const renderPoints = (title, points, sideLabels, sideFields) => (
            <div className="mb-2">
                <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-1" style={{ borderRadius: '3px', lineHeight: '1.2' }}>{title}</h2>
                <table className="w-full text-left" style={{ borderCollapse: 'collapse', fontSize: '9px' }}>
                    <thead>
                        <tr className="bg-gray-100">
                            <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Ponto</th>
                            <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Sentiu?</th>
                            <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>{sideLabels[0]}</th>
                            <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>{sideLabels[1]}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {(points || []).map((row) => (
                            <tr key={row.ponto}>
                                <td className="px-2 py-0.5 font-medium" style={{ border: '1px solid #e5e7eb' }}>{row.ponto}</td>
                                <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row.sentiu ? 'Sim' : 'Não'}</td>
                                <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row[sideFields[0]] || '-'}</td>
                                <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row[sideFields[1]] || '-'}</td>
                            </tr>
                        ))}
                        {(points || []).length === 0 && (
                            <tr><td colSpan="4" className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Sem dados registrados</td></tr>
                        )}
                    </tbody>
                </table>
            </div>
        );
        return (
            <div className="bg-white" style={{ width: '210mm', height: '297mm', padding: '10mm', fontFamily: 'Arial, sans-serif', fontSize: '10px' }}>
                <div className={QT.estesiometria.header + " px-3 py-2 mb-3"} style={{ borderRadius: '3px' }}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-sm font-bold mb-0" style={{ lineHeight: '1.2' }}>Sistema de Questionários - Estesiometria</h1>
                            <p className="text-xs mb-0" style={{ lineHeight: '1.2' }}>Avaliação Sensitiva (Monofilamentos)</p>
                        </div>
                        <div className="text-right" style={{ fontSize: '9px', lineHeight: '1.3' }}>
                            <div>Data de Exportação: {new Date().toLocaleDateString('pt-BR')} {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                            <div>Paciente: {questionnaire.nome_completo}</div>
                        </div>
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Dados Básicos</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome Completo" value={questionnaire.nome_completo} />
                        <InfoRow label="Sexo" value={questionnaire.sexo} />
                        <InfoRow label="Data de Nascimento" value={formatDateShort(questionnaire.data_nascimento)} />
                        <InfoRow label="Idade" value={questionnaire.idade} />
                        <InfoRow label="Clínica" value={questionnaire.clinica || '-'} />
                        <InfoRow label="Data do Exame" value={formatDateShort(questionnaire.data_exame)} />
                        <InfoRow label="Profissional" value={questionnaire.nome_avaliador || '-'} />
                        <InfoRow label="CRM/RG" value={questionnaire.crm_rg || '-'} />
                        <InfoRow label="Diagnóstico" value={questionnaire.diagnostico || '-'} />
                        <InfoRow label="Equipe" value={questionnaire.team?.name} />
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Questionário Pré-Exame</h2>
                    <div className="px-2">
                        {PRE_EXAM.map((q) => (
                            <InfoRow key={q.field} label={q.label} value={questionnaire[q.field] ? 'Sim' : 'Não'} />
                        ))}
                    </div>
                </div>

                {renderPoints('Avaliação dos Pés', questionnaire.pontos_pes, ['Cor Pé Direito', 'Cor Pé Esquerdo'], ['cor_direito', 'cor_esquerdo'])}

                {renderPoints('Avaliação das Mãos', questionnaire.pontos_maos, ['Cor Mão Direita', 'Cor Mão Esquerda'], ['cor_direita', 'cor_esquerda'])}

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Resultado e Classificação</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Pés — % Acerto D / E" value={`${questionnaire.pes_percent_acerto_d ?? '-'} / ${questionnaire.pes_percent_acerto_e ?? '-'}`} />
                        <InfoRow label="Pés — Classificação" value={questionnaire.pes_classificacao || '-'} />
                        <InfoRow label="Mãos — % Acerto D / E" value={`${questionnaire.maos_percent_acerto_d ?? '-'} / ${questionnaire.maos_percent_acerto_e ?? '-'}`} />
                        <InfoRow label="Mãos — Classificação" value={questionnaire.maos_classificacao || '-'} />
                    </div>
                    {questionnaire.comentario && (
                        <div className="px-2 mt-1"><InfoRow label="Observações Clínicas" value={questionnaire.comentario} /></div>
                    )}
                </div>

                <div className="mt-2 pt-2 text-center" style={{ borderTop: '1px solid #d1d5db', position: 'absolute', bottom: '10mm', left: '10mm', right: '10mm' }}>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>
                        Criado em: {new Date(questionnaire.created_at).toLocaleDateString('pt-BR')} {new Date(questionnaire.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>Por: {questionnaire.creator?.name || 'Sistema'}</p>
                </div>
            </div>
        );
    }

    // Dinamometria de Membros Inferiores
    if (type === 'dinamometria_mmii') {
        const mrc = questionnaire.forca_mrc || [];
        const din = questionnaire.dinamometria || [];
        const listLabel = (arr) => (Array.isArray(arr) && arr.length > 0 ? arr.join(', ') : '-');
        return (
            <div className="bg-white" style={{ width: '210mm', height: '297mm', padding: '10mm', fontFamily: 'Arial, sans-serif', fontSize: '10px' }}>
                <div className={QT.dinamometria_mmii.header + " px-3 py-2 mb-3"} style={{ borderRadius: '3px' }}>
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-sm font-bold mb-0" style={{ lineHeight: '1.2' }}>Sistema de Questionários - Dinamometria MMII</h1>
                            <p className="text-xs mb-0" style={{ lineHeight: '1.2' }}>Avaliação Neurológica e Funcional — Membros Inferiores</p>
                        </div>
                        <div className="text-right" style={{ fontSize: '9px', lineHeight: '1.3' }}>
                            <div>Data de Exportação: {new Date().toLocaleDateString('pt-BR')} {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                            <div>Paciente: {questionnaire.nome_completo}</div>
                        </div>
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Dados Básicos</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <InfoRow label="Nome Completo" value={questionnaire.nome_completo} />
                        <InfoRow label="Sexo" value={questionnaire.sexo} />
                        <InfoRow label="Data de Nascimento" value={formatDateShort(questionnaire.data_nascimento)} />
                        <InfoRow label="Idade" value={questionnaire.idade} />
                        <InfoRow label="Peso / Altura" value={`${questionnaire.peso ?? '-'} kg / ${questionnaire.altura ?? '-'} cm`} />
                        <InfoRow label="Dominância" value={questionnaire.dominancia || '-'} />
                        <InfoRow label="Profissão" value={questionnaire.profissao || '-'} />
                        <InfoRow label="Clínica" value={questionnaire.clinica || '-'} />
                        <InfoRow label="Data do Exame" value={formatDateShort(questionnaire.data_exame)} />
                        <InfoRow label="Equipe" value={questionnaire.team?.name} />
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Anamnese (Resumo)</h2>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-0 px-2">
                        <BooleanRow label="Fraqueza muscular?" value={questionnaire.fraqueza_muscular} conditionalValue={questionnaire.fraqueza_lado} />
                        <BooleanRow label="Dor nos membros inferiores?" value={questionnaire.dor_membros} conditionalValue={questionnaire.dor_eva != null ? `EVA ${questionnaire.dor_eva}/10` : null} />
                        <BooleanRow label="Fadiga muscular?" value={questionnaire.fadiga_muscular} />
                        <BooleanRow label="Alteração de equilíbrio?" value={questionnaire.alteracao_equilibrio} />
                        <BooleanRow label="Quedas nos últimos 6 meses?" value={questionnaire.quedas_6meses} conditionalValue={questionnaire.quedas_quantidade} />
                        <InfoRow label="Dispositivo auxiliar" value={questionnaire.dispositivo_auxiliar || 'Não'} />
                    </div>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-1" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Força Muscular — Escala MRC (0–5)</h2>
                    <table className="w-full text-left" style={{ borderCollapse: 'collapse', fontSize: '9px' }}>
                        <thead>
                            <tr className="bg-gray-100">
                                <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Movimento</th>
                                <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Direito</th>
                                <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Esquerdo</th>
                            </tr>
                        </thead>
                        <tbody>
                            {mrc.map((row, i) => (
                                <tr key={i}>
                                    <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row.movimento}</td>
                                    <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row.direito ?? '-'}/5</td>
                                    <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row.esquerdo ?? '-'}/5</td>
                                </tr>
                            ))}
                            {mrc.length === 0 && (<tr><td colSpan="3" className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Sem dados registrados</td></tr>)}
                        </tbody>
                    </table>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-1" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Registro da Dinamometria ({questionnaire.unidade || 'kgf'})</h2>
                    <table className="w-full text-left" style={{ borderCollapse: 'collapse', fontSize: '9px' }}>
                        <thead>
                            <tr className="bg-gray-100">
                                <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Movimento</th>
                                <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Melh. D</th>
                                <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Méd. D</th>
                                <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Melh. E</th>
                                <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Méd. E</th>
                                <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Assim. %</th>
                                <th className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Menor</th>
                            </tr>
                        </thead>
                        <tbody>
                            {din.map((row, i) => (
                                <tr key={i}>
                                    <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row.movimento}</td>
                                    <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row.d_melhor ?? '-'}</td>
                                    <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row.d_media ?? '-'}</td>
                                    <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row.e_melhor ?? '-'}</td>
                                    <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row.e_media ?? '-'}</td>
                                    <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row.assimetria_pct ?? '-'}</td>
                                    <td className="px-2 py-0.5" style={{ border: '1px solid #e5e7eb' }}>{row.menor || '-'}</td>
                                </tr>
                            ))}
                            {din.length === 0 && (<tr><td colSpan="7" className="px-2 py-1" style={{ border: '1px solid #e5e7eb' }}>Sem dados registrados</td></tr>)}
                        </tbody>
                    </table>
                </div>

                <div className="mb-2">
                    <h2 className="text-xs font-bold bg-gray-200 px-2 py-1 mb-2" style={{ borderRadius: '3px', lineHeight: '1.2' }}>Impressão Funcional e Conclusão</h2>
                    <div className="px-2">
                        <InfoRow label="Impressão Funcional" value={listLabel(questionnaire.impressao_funcional)} />
                        <div className="grid grid-cols-2 gap-x-6 gap-y-0">
                            <InfoRow label="Maior Assimetria" value={questionnaire.maior_assimetria_pct != null ? `${questionnaire.maior_assimetria_pct}% (${questionnaire.maior_assimetria_movimento || '-'})` : '-'} />
                            <InfoRow label="Menor Força — Lado" value={questionnaire.menor_forca_lado || '-'} />
                            <InfoRow label="Profissional (Examinador)" value={questionnaire.examinador || '-'} />
                            <InfoRow label="CREFITO/CRM" value={questionnaire.crm_registro || '-'} />
                        </div>
                        {questionnaire.modelo_conclusao && (<div className="mt-1"><InfoRow label="Classificação" value={questionnaire.modelo_conclusao} /></div>)}
                        {questionnaire.conclusao_final && (<div className="mt-1"><InfoRow label="Conclusão Final" value={questionnaire.conclusao_final} /></div>)}
                        {questionnaire.comentario && (<div className="mt-1"><InfoRow label="Comentário" value={questionnaire.comentario} /></div>)}
                    </div>
                </div>

                <div className="mt-2 pt-2 text-center" style={{ borderTop: '1px solid #d1d5db', position: 'absolute', bottom: '10mm', left: '10mm', right: '10mm' }}>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>
                        Criado em: {new Date(questionnaire.created_at).toLocaleDateString('pt-BR')} {new Date(questionnaire.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-gray-600 mb-0" style={{ lineHeight: '1.2' }}>Por: {questionnaire.creator?.name || 'Sistema'}</p>
                </div>
            </div>
        );
    }

    return null;
}