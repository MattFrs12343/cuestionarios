<?php

namespace App\Http\Controllers\Questionnaires;

use App\Http\Controllers\Controller;
use App\Http\Requests\StorePotencialRequest;
use App\Http\Requests\UpdatePotencialRequest;
use App\Models\Potencial;
use App\Support\QuestionnaireFields;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;
use Inertia\Response;

class PotencialController extends Controller
{
    use RestrictsQuestionnaireByTeam, HandlesAttachments;

    /** Slug del cuestionario, para resolver la visibilidad de campos. */
    private const SLUG = 'potencial';

    public function index(Request $request): Response
    {
        $user = $request->user();
        $team = $this->currentTeam($request);

        $query = Potencial::with(['team', 'creator', 'editor'])->where('team_id', $team->id);

        $this->applyIndexFilters($query, $request, ['nome', 'rg'], ['nome', 'clinica', 'rg', 'data_exame', 'created_at']);

        $questionnaires = $query->paginate(15);

        // No mandamos al listado la firma (LONGTEXT base64) ni el pedido
        // medico: no se muestran en la tabla y engordaban el payload de
        // cada pagina (el EEG, con mas registros/fotos, era el que mas sufria).
        $questionnaires->through(fn ($q) => $q->makeHidden(['assinatura_paciente', 'pedido_medico']));

        return Inertia::render('Questionnaires/Potencial/Index', [
            'questionnaires' => $questionnaires,
            'fieldVisibility' => QuestionnaireFields::forInertia($team, self::SLUG),
            'filters' => array_filter($request->only(['search', 'date_from', 'date_to', 'clinica', 'sort', 'direction']), function($value) {
                return $value !== null && $value !== '';
            }),
            'can' => [
                'create' => $user->can('create questionnaires'),
                'edit' => $user->can('edit questionnaires'),
                'delete' => $user->can('delete questionnaires'),
            ],
        ]);
    }

    public function create(Request $request): Response
    {
        return Inertia::render('Questionnaires/Potencial/Create', [
            'retardoMentalGraus' => ['Leve', 'Moderado', 'Grave'],
            // En la creación todavía no hay un equipo concreto: se decide por
            // pertenencia del usuario (ver QuestionnaireFields::forUser).
            'fieldVisibility' => QuestionnaireFields::forUser($request->user(), self::SLUG),
        ]);
    }

    public function store(StorePotencialRequest $request)
    {
        $team = $this->currentTeam($request);

        // Descarta los campos que este equipo no debe ver, antes de guardar.
        $data = QuestionnaireFields::onlyVisible($team, self::SLUG, $request->validated());
        $data['team_id'] = $team->id;
        $data['created_by'] = auth()->id();

        // Manejar assinatura (base64)
        if ($request->filled('assinatura_paciente')) {
            $data['assinatura_paciente'] = $request->assinatura_paciente;
        }

        if ($request->hasFile('pedido_medico')) {
            $filePath = $request->file('pedido_medico')
                ->store('medical_requests', 'private');
            $data['pedido_medico'] = $filePath;
        }
        
        $request->validate($this->attachmentRules());

        $questionnaire = Potencial::create($data);

        $this->storeAttachments($questionnaire, $request);

        return redirect()->route('questionnaires.potencial.index')
            ->with('success', 'Questionário de Potencial criado com sucesso!');
    }

    public function show(Potencial $potencial): Response
    {
        $this->authorizeTeamAccess($potencial);

        $potencial->load(['team', 'creator', 'editor', 'attachments']);

        return Inertia::render('Questionnaires/Potencial/Show', [
            'questionnaire' => $potencial,
            'pedidoMedicoUrl' => $potencial->pedido_medico
                ? route('pedidos-medicos.show', ['type' => 'potencial', 'id' => $potencial->id])
                : null,
            'fieldVisibility' => QuestionnaireFields::forInertia($potencial->team, self::SLUG),
            'can' => [
                'edit' => auth()->user()->can('update', $potencial),
                'delete' => auth()->user()->can('delete', $potencial),
            ],
        ]);
    }

    public function edit(Potencial $potencial): Response
    {
        $this->authorizeTeamAccess($potencial);

        $potencial->load(['team', 'creator', 'editor', 'attachments']);

        return Inertia::render('Questionnaires/Potencial/Edit', [
            'questionnaire' => $potencial,
            'pedidoMedicoUrl' => $potencial->pedido_medico
                ? route('pedidos-medicos.show', ['type' => 'potencial', 'id' => $potencial->id])
                : null,
            'fieldVisibility' => QuestionnaireFields::forInertia($potencial->team, self::SLUG),
            'retardoMentalGraus' => ['Leve', 'Moderado', 'Grave'],
        ]);
    }

    public function update(UpdatePotencialRequest $request, Potencial $potencial)
    {
        $this->authorizeTeamAccess($potencial);

        // Se filtra contra el equipo del registro, no el actual: es el que
        // determina qué campos puede tener guardados este cuestionario.
        $data = QuestionnaireFields::onlyVisible($potencial->team, self::SLUG, $request->validated());
        $data['updated_by'] = auth()->id();

        // Manejar assinatura (base64)
        if ($request->filled('assinatura_paciente')) {
            $data['assinatura_paciente'] = $request->assinatura_paciente;
        }

        if ($request->hasFile('pedido_medico')) {
            // Eliminar archivo anterior si existe
            if ($potencial->pedido_medico) {
                Storage::disk('private')->delete($potencial->pedido_medico);
            }
            $filePath = $request->file('pedido_medico')
                ->store('medical_requests', 'private');
            $data['pedido_medico'] = $filePath;
        } else {
            // Si no hay archivo nuevo, mantener el archivo actual
            unset($data['pedido_medico']);
        }
        
        $request->validate($this->attachmentRules());

        $potencial->update($data);

        $this->storeAttachments($potencial, $request);

        return redirect()->route('questionnaires.potencial.index')
            ->with('success', 'Questionário de Potencial atualizado com sucesso!');
    }

    public function destroy(Potencial $potencial)
    {
        $this->authorizeTeamAccess($potencial);

        if ($potencial->pedido_medico) {
            Storage::disk('private')->delete($potencial->pedido_medico);
        }

        $potencial->delete();

        return redirect()->route('questionnaires.potencial.index')
            ->with('success', 'Questionário de Potencial excluído com sucesso!');
    }
}